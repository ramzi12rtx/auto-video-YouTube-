from video_generator import generate_video
from uploader import upload_video

generate_video("هذا الفيديو تم إنشاؤه تلقائيًا 😎")
upload_video()